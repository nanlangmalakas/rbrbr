<?php

namespace BIS\CMSBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BISCMSBundle extends Bundle
{
}
